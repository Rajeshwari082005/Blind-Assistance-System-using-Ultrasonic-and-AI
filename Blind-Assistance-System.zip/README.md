# Blind Assistance System using Ultrasonic and AI

## Overview
This project assists visually impaired individuals using two modules:
1. **Ultrasonic Sensor with Arduino**: Detects nearby obstacles and alerts with a buzzer/vibration.
2. **AI Object Detection (Python + OpenCV)**: Identifies objects in front of the user via a camera and provides feedback.

## Components
- Arduino Uno/Nano
- Ultrasonic Sensor (HC-SR04)
- Buzzer / Vibration Motor
- Raspberry Pi / Laptop with Camera
- OpenCV + Pretrained MobileNet SSD

## Files
- ultrasonic.ino → Arduino code for obstacle detection
- ai_detection.py → Python AI object detection code
- README.md → Documentation
